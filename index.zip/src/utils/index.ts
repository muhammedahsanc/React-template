  import {notify} from "./toasts";
  import {errorToast} from "./toastError";
  import {emailRegex} from "./mailValidation";


  export { notify,errorToast,emailRegex }