import {Login, Signup} from "../components/Auth";

function Page() {

  return(
   <Login />
  )
}

export default Page;
