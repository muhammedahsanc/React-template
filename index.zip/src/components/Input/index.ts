import  InputPassword  from "./InputPassword";
import  InputBox  from "./InputBox";

export {InputPassword,InputBox}