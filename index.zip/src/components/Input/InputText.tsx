
function InputText() {
  return (
    <div>InputText</div>
  )
}

export default InputText