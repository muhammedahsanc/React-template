import {  toast } from 'react-toastify'
const notify = (message:string) => toast.success(message);
export {notify}