import {  toast } from 'react-toastify'
const errorToast = (message:string) => toast.error(message);
export {errorToast}