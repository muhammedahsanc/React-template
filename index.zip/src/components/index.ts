// import Button from "./buttons/Button";
// import InputPassword from "./Input/InputPassword"
// import Signup from "./Auth/Signup";
// import Login from "./Auth/Login";


// export { Button,InputPassword,Signup,Login};