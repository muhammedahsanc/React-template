import {Page} from "./pages"
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer } from 'react-toastify';
import { Provider } from "react-redux";
import { store } from "./redux/store";
function App() {

  return (
    <div>
    <ToastContainer />
<Provider store={store}>
  <Page/>
  </Provider>
  </div>
    
  )
}

export default App
