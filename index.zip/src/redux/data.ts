import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface UserDataState {
    userList: string[];
}

const INITIAL_STATE: UserDataState = {
    userList: [],
};

const dataSlice = createSlice({
    name: "userdata",
    initialState: INITIAL_STATE,
    reducers: {
        addToList: (state, action) => {
            console.log(action.payload);
            state.userList.push(action.payload);

        },
    },
});

export const { addToList } = dataSlice.actions;

export default dataSlice.reducer;
