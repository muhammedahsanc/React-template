import styled from "styled-components";
import {  InputChange,loginDataProps } from "../../interfaces";
import { InputPassword,InputBox } from "../Input";
import { Button, CancelButton } from "../buttons";
import { useState } from "react";
import {loginSubmit} from "../loginSubmit"
import {emailRegex} from "../../utils"
// import { useSelector } from 'react-redux';
function Login() {
  // const {userList} = useSelector((state:any)=>state.userData)
  // console.log(userList);
  
  const [formData, setFormData] = useState<loginDataProps>({
    username: "",
    password: "",
  });
  const [error, setError] = useState<string>(""); 
  const checkEmail = (e: InputChange) => {
    const enteredEmail = e.target.value;
    setFormData({ ...formData, username: enteredEmail });
    if (emailRegex.test(enteredEmail) === false)
      setError("Please enter a valid email address");
    else setError("");
    if (enteredEmail == "") setError("");
  };
  return (
    <Wrapper>
      <SignupContainer>
        <h2>Login</h2>
        <SignupForm>
          <InputBox
            error={error}
            value={formData.username}
            onChange={checkEmail}
            placeholder="Username"
          />
          <InputPassword
            value={formData.password}
            placeholder={"Password"}
            onChange={(e) => {
              setFormData({ ...formData, password: e.target.value });
            }}
          />
          <Button submit={() =>loginSubmit({formData,setFormData,error,})} buttonName="Login" />
          <CancelButton
            onClick={() =>
              setFormData({ username: "", password: ""})
            }
          />
        </SignupForm>
      </SignupContainer>
    </Wrapper>
  );
}
const Wrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100vh;
`;
const SignupContainer = styled.div`
  max-width: 310px;
  margin: 0 auto;
  padding: 50px;
  border: 1px solid #ccc;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
`;

const SignupForm = styled.div`
  display: flex;
  flex-direction: column;
`;

export default Login;
